
tictactoe_grid = [
  ['E', 'E', 'E'],
  ['E', 'E', 'E'],
  ['E', 'E', 'E']
]
def print_grid(tictactoe_grid):
  for i in tictactoe_grid:
    print(i)
print_grid(tictactoe_grid)
num_xmoves = 0
xplay = 0
oplay = 0
import random
rand_num1 = random.randint(0,2)
rand_num2 = random.randint(0,2)
while num_xmoves < 6:
    user_row = int(input ('X Enter the row for your guess (0-2): '))
    user_col = int(input('X Enter the column for your guess (0-2): '))
    if user_row > 2:
      print ('Try Again')
    elif user_row < 0:
      print ('Try Again')
    if user_col > 2:
      print ('Try Again')
    elif user_col < 0:
      print ('Try Again')
    xplay = tictactoe_grid[user_row][user_col]
    if xplay == 'E':
        tictactoe_grid[user_row][user_col] = 'X'
        print_grid (tictactoe_grid)
    print ('____________')
    num_xmoves += 1
    user_row = int(input ('O Enter the row for your guess (0-2): '))
    user_col = int(input('O Enter the column for your guess (0-2): '))
    if user_row > 2:
      print ('Try Again')
    elif user_row < 0:
      print ('Try Again')
    if user_col > 2:
      print ('Try Again')
    elif user_col < 0:
      print ('Try Again')
    oplay = tictactoe_grid[user_row][user_col]
    if oplay == 'E':
        tictactoe_grid[user_row][user_col] = 'O'
        print_grid (tictactoe_grid)
    print ('____________')